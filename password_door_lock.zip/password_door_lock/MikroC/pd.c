    int kpi;
    char actual_password[]="12345#";
    char given_password[]="000000";
    // Keypad module connections
    char keypadPort at PORTD;
    // End Keypad module connections
    // LCD Module connections
    sbit LCD_RS at RB2_bit;
    sbit LCD_EN at RB3_bit;
    sbit LCD_D7 at RB7_bit;
    sbit LCD_D6 at RB6_bit;
    sbit LCD_D5 at RB5_bit;
    sbit LCD_D4 at RB4_bit;
    // End LCD module connections
    // LCD Pin direction
    sbit LCD_RS_Direction at TRISB2_bit;
    sbit LCD_EN_Direction at TRISB3_bit;
    sbit LCD_D7_Direction at TRISB7_bit;
    sbit LCD_D6_Direction at TRISB6_bit;
    sbit LCD_D5_Direction at TRISB5_bit;
    sbit LCD_D4_Direction at TRISB4_bit;
    // End of LCD Pin direction
    
    //=======DOOR CLOSE================================
   void door_close(){
   int k=0,l=1;
           Lcd_Cmd(_LCD_CLEAR); // Clear Display
           Lcd_Cmd(_LCD_CURSOR_OFF); // Cursor Off
           Lcd_Out(1,1,"hit * for close");
           delay_ms(200); // 0.2s delay

       // Keypad_Init(); // Initializing Keypad

       Lcd_Cmd(_LCD_BLINK_CURSOR_ON); // blinking Cursor ON
       Lcd_Cmd(_LCD_SECOND_ROW); // Cursor Off
                            //Keyboard Input   =============================================
                             do
                              {
                               kpi = 0; // Reset key code variable
                                      // Wait for key to be pressed and released
                              do
                              kpi = Keypad_Key_Click(); // Store key code in kpi variable
                               while (!kpi);

                              switch (kpi)
                              {
                               case 1: kpi = 55; break; // 7-Cmp kpi with equivalent ASCII code of 7, break if equal
                               case 2: kpi = 52; break; // 4
                               case 3: kpi = 49; break; // 1
                               case 4: kpi = 42; break; // *
                               case 5: kpi = 56; break; // 8
                               case 6: kpi = 53; break; // 5
                               case 7: kpi = 50; break; // 2
                               case 8: kpi = 48; break; // 0
                               case 9: kpi = 57; break; // 9
                               case 10: kpi = 54; break; // 6
                               case 11: kpi = 51; break; // 3
                               case 12: kpi = 35; break; // #
                            }
                            } while (kpi!=42);
if(kpi==42){
       Lcd_Cmd(_LCD_CLEAR); // Clear Display
       Lcd_Cmd(_LCD_CURSOR_OFF); // Cursor Off

       Lcd_Out(1,1,"Enter Password:");
       delay_ms(200); // 0.2s delay

       // Keypad_Init(); // Initializing Keypad

       Lcd_Cmd(_LCD_BLINK_CURSOR_ON); // blinking Cursor ON
       Lcd_Cmd(_LCD_SECOND_ROW); // Cursor Off

     do
      {
       kpi = 0; // Reset key code variable
              // Wait for key to be pressed and released
      do
      kpi = Keypad_Key_Click(); // Store key code in kpi variable
       while (!kpi);

      switch (kpi)
      {
       case 1: kpi = 55; break; // 7-Cmp kpi with equivalent ASCII code of 7, break if equal
       case 2: kpi = 52; break; // 4
       case 3: kpi = 49; break; // 1
       case 4: kpi = 42; break; // *
       case 5: kpi = 56; break; // 8
       case 6: kpi = 53; break; // 5
       case 7: kpi = 50; break; // 2
       case 8: kpi = 48; break; // 0
       case 9: kpi = 57; break; // 9
       case 10: kpi = 54; break; // 6
       case 11: kpi = 51; break; // 3
       case 12: kpi = 35; break; // #
    }
        given_password[k]=kpi;
       Lcd_Chr(2, l, kpi); // Print key ASCII value on Lcd
               l++;
                k++;
    } while(kpi!=35);
     if(given_password[0]==actual_password[0] && given_password[1]==actual_password[1] && given_password[2]==actual_password[2] && given_password[3]==actual_password[3] && given_password[4]==actual_password[4] && given_password[5]==actual_password[5]){

                        Lcd_Cmd(_LCD_CLEAR); // Clear Display
                        Lcd_Cmd(_LCD_CURSOR_OFF); // Cursor Off
                        Lcd_Out(1,1,"DOOR CLOSED");
                        Lcd_Out(2,1,"successfully");
                        delay_ms(200); // 0.2s delay
                        }
                        } //end if *
}
//=======================End DOOR CLOSED================

   //====================Enter Password ==================
    void password_prompt(){
    int i=1,j=0;
       Lcd_Cmd(_LCD_CLEAR); // Clear Display
       Lcd_Cmd(_LCD_CURSOR_OFF); // Cursor Off

       Lcd_Out(1,1,"Enter Password:");
       delay_ms(200); // 0.2s delay

         Keypad_Init(); // Initializing Keypad

       Lcd_Cmd(_LCD_BLINK_CURSOR_ON); // blinking Cursor ON
       Lcd_Cmd(_LCD_SECOND_ROW); // Cursor Off

     do
      {
       kpi = 0; // Reset key code variable
              // Wait for key to be pressed and released
      do
      kpi = Keypad_Key_Click(); // Store key code in kpi variable
       while (!kpi);

      switch (kpi)
      {
       case 1: kpi = 55; break; // 7-Cmp kpi with equivalent ASCII code of 7, break if equal
       case 2: kpi = 52; break; // 4
       case 3: kpi = 49; break; // 1
       case 4: kpi = 42; break; // *
       case 5: kpi = 56; break; // 8
       case 6: kpi = 53; break; // 5
       case 7: kpi = 50; break; // 2
       case 8: kpi = 48; break; // 0
       case 9: kpi = 57; break; // 9
       case 10: kpi = 54; break; // 6
       case 11: kpi = 51; break; // 3
       case 12: kpi = 35; break; // #

    }
        given_password[j]=kpi;
       Lcd_Chr(2, i, kpi); // Print key ASCII value on Lcd
               i++;
                j++;
    } while (kpi!=35);
//     password_check();     //Check for valid password

    }

 //====================End Enter Password===================
//==============PASSWORD CHECK =====================
        void password_check(){

        if(given_password[0]==actual_password[0] && given_password[1]==actual_password[1] && given_password[2]==actual_password[2] && given_password[3]==actual_password[3] && given_password[4]==actual_password[4] && given_password[5]==actual_password[5]){

                            Lcd_Cmd(_LCD_CLEAR); // Clear Display
                            Lcd_Cmd(_LCD_CURSOR_OFF); // Cursor Off
                            Lcd_Out(1,1,"DOOR OPEN");
                            Lcd_Out(2,1,"successfully");
                            delay_ms(200); // 0.2s delay
                            door_close();
                } //End IF
                else{
                           Lcd_Cmd(_LCD_CLEAR); // Clear Display
                            Lcd_Cmd(_LCD_CURSOR_OFF); // Cursor Off
                            Lcd_Out(1,1,"Wrong Password");
                            Lcd_Out(2,1,"Please Try Again");
                            delay_ms(200); // 0.2s delay
                            password_prompt();
                             if(given_password[0]==actual_password[0] && given_password[1]==actual_password[1] && given_password[2]==actual_password[2] && given_password[3]==actual_password[3] && given_password[4]==actual_password[4] && given_password[5]==actual_password[5]){

                            Lcd_Cmd(_LCD_CLEAR); // Clear Display
                            Lcd_Cmd(_LCD_CURSOR_OFF); // Cursor Off
                            Lcd_Out(1,1,"DOOR OPEN");
                            Lcd_Out(2,1,"successfully");
                            delay_ms(200); // 0.2s delay
                            door_close();
                } //End IF
                         }//End Else

                }//End function
   //===========End Check Password===================

    void main() {
      Lcd_Init(); // Initializing LCD
      Lcd_Cmd(_LCD_CLEAR); // Clear Display
      Lcd_Cmd(_LCD_CURSOR_OFF); // Cursor Off
      Lcd_Out(1,1,"Password Door");  // Write "KEYPAD INTERFACE" in the first row
      Lcd_Out(2,1,"Lock System");
      delay_ms(200); // 0.2s delay

        password_prompt();     //CALL FUNCTION for password input
         password_check();   //Check Password
    }